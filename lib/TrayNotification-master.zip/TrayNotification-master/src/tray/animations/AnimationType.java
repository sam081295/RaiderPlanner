package tray.animations;

public enum AnimationType {
    FADE,
    SLIDE,
    POPUP
}
